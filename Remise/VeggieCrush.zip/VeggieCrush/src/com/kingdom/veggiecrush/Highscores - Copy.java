/*
package com.kingdom.veggiecrush;

import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.kingdom.veggiecrush.Settings.GameMode;
import com.kingdom.veggiecrush.Settings.Source;
 
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class Highscores extends Activity implements OnClickListener {

	private GameMode modePrecedent = null;
	
	@SuppressWarnings("unused")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_highscores);
		
		Source activityPrecedent = (Source) getIntent().getExtras().get(Settings.EXTRA_SOURCE);
				
		try {
			hardCodeSharedPref();
		} catch (JSONException e) { e.printStackTrace(); }
		
		if(activityPrecedent == Settings.Source.GAME) {
			Button btnPlayAgain = (Button) findViewById(R.id.btnPlayAgain);
			btnPlayAgain.setOnClickListener(this);
			Button btnOtherMode = (Button) findViewById(R.id.btnOtherMode);
			btnOtherMode.setOnClickListener(this);
			
			// LOG SCORE
			PriorityQueue<PlayerScore> queue;
			try {
				queue = getScores();
				Iterator<PlayerScore> it = queue.iterator();
				Integer scoreGamePrec = Integer.parseInt((String) getIntent().getExtras().get(Settings.EXTRA_PLAYER_SCORE));
				String playerName = (String) getIntent().getExtras().get(Settings.EXTRA_PLAYER_NAME);
				
				while (it.hasNext()) {
				   PlayerScore ps = it.next();
				   if(scoreGamePrec > Integer.parseInt(ps.score)) {
					   PlayerScore lowest = findLowestPlayer(queue);
					   queue.remove(lowest);
					   queue.add(new PlayerScore(playerName, scoreGamePrec.toString()));
					   break;
				   }
				}
				
				setScores(queue);
			} catch (JSONException e) { e.printStackTrace(); }
			
		} else if(activityPrecedent == Settings.Source.MENU) {
			Button btnPlayAgain = (Button) findViewById(R.id.btnPlayAgain);
			btnPlayAgain.setVisibility(View.INVISIBLE);
			Button btnOtherMode = (Button) findViewById(R.id.btnOtherMode);
			btnOtherMode.setVisibility(View.INVISIBLE);
		}
		
		Button btnExit = (Button) findViewById(R.id.btnQuit);
		btnExit.setOnClickListener(this);
		
		
		populateHighScores();
	}
	
	public PlayerScore findLowestPlayer(PriorityQueue<PlayerScore> queue) {
		PlayerScore playerLower = null;
		int scoreMin = 0, cpt = 0;
		while(!queue.isEmpty()) {
			PlayerScore ps = queue.poll();
			if(cpt == 0) {
				scoreMin = Integer.parseInt(ps.score);
				playerLower = ps;
			}
			if(Integer.parseInt(ps.score) < scoreMin) {
				playerLower = ps;
			}
			cpt++;
		}
		return playerLower;
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId())
		{
			case R.id.btnPlayAgain:
				Intent intentPlayAgain = new Intent(this, Game.class);
				modePrecedent = (GameMode) getIntent().getExtras().get(Settings.EXTRA_GAME_MODE);
				String namePlayer = (String) getIntent().getExtras().get(Settings.EXTRA_PLAYER_NAME);
				intentPlayAgain.putExtra(Settings.EXTRA_GAME_MODE, modePrecedent);
				intentPlayAgain.putExtra(Settings.EXTRA_PLAYER_NAME, namePlayer);
				startActivity(intentPlayAgain);
				finish();
				break;
			
			case R.id.btnOtherMode:
				Intent intentOtherMode = new Intent(this, Game.class);
				modePrecedent = (GameMode) getIntent().getExtras().get(Settings.EXTRA_GAME_MODE);
				if (modePrecedent == GameMode.TIME_ATTACK) {
					intentOtherMode.putExtra(Settings.EXTRA_GAME_MODE, Settings.GameMode.BLITZ);
				} else if (modePrecedent == GameMode.BLITZ) {
					intentOtherMode.putExtra(Settings.EXTRA_GAME_MODE, Settings.GameMode.TIME_ATTACK);
				}
				intentOtherMode.putExtra(Settings.EXTRA_PLAYER_NAME, (String) getIntent().getExtras().get(Settings.EXTRA_PLAYER_NAME));
				startActivity(intentOtherMode);
				finish();
				break;
				
			case R.id.btnQuit:
				finish();
				break;
		}
	}
	
	public void setScores(PriorityQueue<PlayerScore> queue) throws JSONException {
		
		JSONObject mainObj = new JSONObject();
		String playerNames[] = {"player1","player2","player3","player4","player5"};
		int cpt = 0;
		
		while(!queue.isEmpty()) {
			PlayerScore ps = queue.poll();
			JSONObject jo = new JSONObject();
			jo.put("name", ps.name);
			jo.put("score", ps.score);
			mainObj.put(playerNames[cpt++], jo) ;
		}
		
		SharedPreferences prefs = this.getSharedPreferences("com.kingdom.veggiecrush", Context.MODE_PRIVATE);
		Editor editor = prefs.edit();
		String tmp = mainObj.toString();
		editor.putString("highScores", mainObj.toString());
		editor.commit();
	}
	
	public void hardCodeSharedPref() throws JSONException {
		//SharedPreferences prefs = this.getSharedPreferences("com.kingdom.veggiecrush", Context.MODE_PRIVATE);
		//Editor editor = prefs.edit();
		//editor.putString("highScores","{\"player5\":{\"name\":\"joueurA\",\"score\":\"200\"},\"player4\":{\"name\":\"joueurB\",\"score\":\"400\"},\"player3\":{\"name\":\"joueurC\",\"score\":\"300\"},\"player2\":{\"name\":\"joueurD\",\"score\":\"100\"},\"player1\":{\"name\":\"joueurE\",\"score\":\"5000\"}}");
		//editor.commit();
		
		
	}
	
	public PriorityQueue<PlayerScore> getScores() throws JSONException {
		SharedPreferences sharedPref = this.getSharedPreferences("com.kingdom.veggiecrush", Context.MODE_PRIVATE);
		String strJson = sharedPref.getString("highScores", null);
		
		Comparator<PlayerScore> comparator = new PlayerScoreComparator();
        PriorityQueue<PlayerScore> queue = new PriorityQueue<PlayerScore>(5, comparator);
        
        JSONObject jsonData = new JSONObject(strJson);
		for(Iterator<String> iter = jsonData.keys(); iter.hasNext();) {
		    String key = iter.next();
		    PlayerScore ps = new PlayerScore(jsonData.getJSONObject(key).getString("name"), jsonData.getJSONObject(key).getString("score"));
		    queue.add(ps);
		}
		return queue;
	}
	
	public void populateHighScores() {    
		PriorityQueue<PlayerScore> queue;
		try {
			queue = getScores();
			
			int idNames[] = {R.id.scoresName1, R.id.scoresName2, R.id.scoresName3, R.id.scoresName4, R.id.scoresName5};
			int idScores[] = {R.id.scoresScore1, R.id.scoresScore2, R.id.scoresScore3, R.id.scoresScore4, R.id.scoresScore5};
			
			TextView nameView;
			
			int cpt = 0;
			while(!queue.isEmpty()) {
				PlayerScore ps = queue.poll();
				nameView = (TextView) findViewById(idNames[cpt]);
				nameView.setText(ps.name);
				nameView = (TextView) findViewById(idScores[cpt]);
				nameView.setText(ps.score);
				++cpt;
		    }
		} catch (JSONException e) { e.printStackTrace(); }
		
		
		
	}

	public class PlayerScore {

	    private String name;
	    private String score;

	    public PlayerScore(String name, String score) {
	    	this.name = name; 
		    this.score = score;
	    }
	}
	
	

	public class PlayerScoreComparator implements Comparator<PlayerScore>{
	    @Override
	    public int compare(PlayerScore x, PlayerScore y) {
	    	return Integer.valueOf(Integer.parseInt(y.score)).compareTo(Integer.parseInt(x.score));
	    }
	}
	
}
*/